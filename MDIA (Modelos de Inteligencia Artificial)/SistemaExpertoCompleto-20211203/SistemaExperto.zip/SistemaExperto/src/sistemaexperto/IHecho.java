package sistemaexperto;

public interface IHecho {
    // Interface para todos los hechos que se debe implementar

    String Nombre();
    Object Valor(); // posteriormente será o Entero o Booleano
    int Nivel();
    String Pregunta();
    
    void setNivel(int l); // Permite modificar el nivel de un hecho

}
