package sistemaexperto;

public class HechoBooleano implements IHecho {
    protected String nombre; // Nombre del hecho
  
    protected int nivel;    // Nivel (0 para los hechos como entrada)

    protected boolean valor; // Valor booleano del hecho

    // Pregunta que se debe hacer al usuario si es necesario
    protected String pregunta;

    @Override
    public String Nombre() {
        return nombre;
    }

    @Override
    public Object Valor() {
        return valor;
    }

    @Override
    public int Nivel() {
        return nivel;
    }

    @Override
    public void setNivel(int n) {
        nivel = n;
    }

    @Override
    public String Pregunta() {
        return pregunta;
    }

    // Constructor
    public HechoBooleano(String _nombre , boolean _valor, String _pregunta, int _nivel) {
        nombre = _nombre ;
        valor = _valor;
        pregunta = _pregunta;
        nivel = _nivel;
    }

    // Métodos toString (para la visualización)
    // de la forma Hecho(nivel) o !Hecho(nivel)
    @Override
    public String toString() {
        String res = "";
        if (!valor) {
            res += "!";
        }
        res += nombre + " (" + nivel + ")";
        return res;
    }

}
