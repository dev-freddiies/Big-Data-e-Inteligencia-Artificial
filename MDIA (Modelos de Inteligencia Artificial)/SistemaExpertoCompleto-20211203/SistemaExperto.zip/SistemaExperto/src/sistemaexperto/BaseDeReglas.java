package sistemaexperto;

import java.util.ArrayList;

public class BaseDeReglas {
    /**
     * Contiene una ista de reglas accesible en lectura o escritura a través de métodos.
     * Cuando se cree una nueva Base de reglas a partir de una lista de reglas hay que tener la 
     * precaución de copiarlas una a una para que la eliminación de una regla en la base de reglas
     * no provoque la eliminacion del contenido de la base de reglas
     */
    protected ArrayList<Regla> reglas;

    public BaseDeReglas() {
        this.reglas = new ArrayList();
    }

    public ArrayList<Regla> getReglas() {
        return reglas;
    }

    /**
     * Método para copiar y agregar reglas de un array reglasnuevas
     * @param reglas
     */
    public void setReglas(ArrayList<Regla> reglasnuevas) {
        for (Regla r : reglasnuevas) {
            Regla copia = new Regla (r.nombre, r.premisas, r.conclusion);
            this.reglas.add(copia);
        } 
    }

    public void ClearBase()
    {
        this.reglas.clear();
    }

    public void AgregarRegla(Regla r)
    {
        this.reglas.add(r);
    }
    
    public void EliminarRegla(Regla r)
    {
        this.reglas.remove(r);
    }
    
    
}
