package sistemaexperto;
import java.util.ArrayList;

public class BaseDeHechos {
    
    protected ArrayList<IHecho> hechos;   // Lista de los hechos

    // Constructor
    public BaseDeHechos() { 
        hechos = new ArrayList(); 
    } 
    public ArrayList<IHecho> getHechos () { 
        return hechos; 
    } 
  
       // Vaciar la base
    public void Vaciar() {
        hechos.clear();
    }
    
    // Agregar un hecho
    public void AgregarHecho(IHecho hecho) {
        hechos.add(hecho);
    }
    
      //Hacen falta métodos más específicos

    // Buscar un hecho a partir de su nomnre, null si no existe
    public IHecho Buscar(String nombre) {
        for(IHecho hecho: hechos) {
            if (hecho.Nombre().equals(nombre)) {
                return hecho;
            }
        }
        return null;
    }
  //RecuperarValorhecho 
    // Busca el valor de un hecho, null si el hecho no existe
    public Object RecuperarValorHecho(String nombre) {
        for(IHecho hecho : hechos) {
            if (hecho.Nombre().equals(nombre)) {
                return hecho.Valor();
            }
        }
        return null;
    }
}
